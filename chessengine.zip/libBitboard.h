#pragma once

#ifndef LIBBITBOARD_H
#define LIBBITBOARD_H

#include "bitboard/BB_BITBOARD.h"
#include "bitboard/BB_RANK.h"
#include "bitboard/BB_FILE.h"
#include "bitboard/BB_SQUARE.h"
#endif