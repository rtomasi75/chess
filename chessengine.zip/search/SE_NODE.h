#pragma once
#ifndef SE_NODE_H
#define SE_NODE_H

#include "libMovegen.h"

struct SE_NODE
{
	MG_POSITION* pPosition;
};

#endif