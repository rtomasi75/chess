#pragma once

#include <cstdint>

#ifndef PYGMALION_BOARD
#define PYGMALION_BOARD

#define PYGMALION_COUNT_PIECES 6
#define PYGMALION_COUNT_PLAYERS 2

typedef std::uint64_t BITBOARD;

struct PlayerPieces
{
	BITBOARD 
};

#endif