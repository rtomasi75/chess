#pragma once
#ifndef LIBSEARCH_H
#define LIBSEARCH_H

#include "search/SE_GAME.h"

#endif