#pragma once
#ifndef CM_COMPILER_H
#define CM_COMPILER_H

#ifndef __MSCVER__

#define abstract =0

#endif

#endif