#include "MG_MOVELIST.h"

void MOVELIST_Initialize(MG_MOVELIST* pMoveList)
{
	pMoveList->CountMoves = 0;
}
