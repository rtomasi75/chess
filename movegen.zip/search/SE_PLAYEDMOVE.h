#pragma once
#ifndef SE_PLAYEDMOVE_H
#define SE_PLAYEDMOVE_H

#include "libMovegen.h"

struct SE_PLAYEDMOVE
{
	MG_MOVE Move;
	MG_MOVEDATA MoveData;
};

#endif