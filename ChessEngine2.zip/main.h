﻿// pygmalion.h: Includedatei für Include-Standardsystemdateien
// oder projektspezifische Includedateien.

#pragma once

#include <iostream>

// TODO: Verweisen Sie hier auf zusätzliche Header, die Ihr Programm erfordert.
