#pragma once
#ifndef SE_FSM_H
#define SE_FSM_H

typedef void (*SE_FSM)(SE_THREAD* pThread, SE_CONTEXTPTR pContext, const MG_MOVEGEN* pMoveGen);

#endif // SE_FSM_H