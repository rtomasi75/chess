#pragma once
#ifndef LIBCOMMON_H
#define LIBCOMMON_H

#include "common/CM_Compiler.h"
#include "common/CM_Assert.h"
#include "common/CM_Intrinsics.h"

#endif