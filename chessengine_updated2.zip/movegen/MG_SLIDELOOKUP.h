#pragma once
#ifndef MG_SLIDELOOKUP_H
#define MG_SLIDELOOKUP_H

#include <cstdint>

#include "libBitboard.h"

#include "MG_SLIDEMASKS.h"
#include "MG_PIECETYPE.h"
#include "MG_MOVE.h"
#include "../libCommon.h"

struct MG_MOVEGEN;

struct CM_ALIGN_CACHELINE MG_SLIDELOOKUP
{
	MG_SLIDEMASKINDEX CountMasks;
	MG_SLIDEMASKINDEX MaskIndex[COUNT_SLIDEMASKS];
#if defined(CM_ALIGNMENT_CACHELINE) && (CM_ALIGNMENT_CACHELINE >= 64)
	std::uint8_t Padding[62];
#endif
};

struct CM_ALIGN_CACHELINE MG_SLIDELOOKUP_COLD
{
	CM_ALIGN_CACHELINE MG_MOVE MoveBase[COUNT_PLAYERS][COUNT_SLIDEMASKS][COUNT_SQUARES];
	CM_ALIGN_CACHELINE MG_MOVE CaptureBase[COUNT_PLAYERS][COUNT_SLIDEMASKS][COUNT_SQUARES][COUNT_PIECETYPES];
};

#endif